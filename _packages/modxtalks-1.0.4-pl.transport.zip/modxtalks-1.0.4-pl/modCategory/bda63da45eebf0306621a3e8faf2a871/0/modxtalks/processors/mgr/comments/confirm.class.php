<?php
/**
 * Confirm unconfirmed post
 *
 * @package modxtalks
 * @subpackage processors
 */