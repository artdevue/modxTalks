<?php
/**
 * Update unconfirmed post
 *
 * @package modxtalks
 * @subpackage processors
 */