<?php

$xpdo_meta_map = array(
    'modResource' =>
        array(
            0 => 'CommentsModxTalks',
        ),
    'xPDOSimpleObject' =>
        array(
            0 => 'modxTalksPost',
            1 => 'modxTalksConversation',
            2 => 'modxTalksTempPost',
            3 => 'modxTalksIpBlock',
            4 => 'modxTalksLike',
            5 => 'modxTalksSubscribers',
            6 => 'modxTalksEmailBlock',
        ),
);
