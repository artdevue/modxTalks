<?php
require_once(dirname(dirname(__FILE__)) . '/modxtalkspost.class.php');

class modxTalksPost_mysql extends modxTalksPost {
    public function test() {
        return 'test';
    }
}
