<?php
require_once(dirname(dirname(__FILE__)) . '/commentsmodxtalks.class.php');

class CommentsModxTalks_mysql extends CommentsModxTalks {
}
