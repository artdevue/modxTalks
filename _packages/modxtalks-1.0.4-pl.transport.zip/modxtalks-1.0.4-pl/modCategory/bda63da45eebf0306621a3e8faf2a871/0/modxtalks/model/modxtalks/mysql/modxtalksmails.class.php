<?php
require_once(dirname(dirname(__FILE__)) . '/modxtalksmails.class.php');

class modxTalksMails_mysql extends modxTalksMails {
}
