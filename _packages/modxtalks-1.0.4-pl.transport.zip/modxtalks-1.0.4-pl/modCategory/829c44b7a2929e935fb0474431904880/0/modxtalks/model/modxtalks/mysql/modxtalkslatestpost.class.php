<?php
require_once(dirname(dirname(__FILE__)) . '/modxtalkslastestpost.class.php');

class modxTalksLatestPost_mysql extends modxTalksLatestPost {
}
