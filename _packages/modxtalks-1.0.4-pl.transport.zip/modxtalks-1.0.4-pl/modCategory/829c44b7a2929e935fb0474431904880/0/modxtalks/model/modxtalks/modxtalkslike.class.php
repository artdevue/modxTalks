<?php

class modxTalksLike extends xPDOSimpleObject {
}
