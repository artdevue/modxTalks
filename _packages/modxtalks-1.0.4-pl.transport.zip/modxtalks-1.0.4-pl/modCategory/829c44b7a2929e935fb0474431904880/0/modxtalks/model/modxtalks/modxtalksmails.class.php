<?php

class modxTalksMails extends xPDOSimpleObject {
}
