<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
Extra: MODXTalks
--------------------
Version: 1.0.4 pl
Since: January, 2013
Author: Valentin Rasulov <info@artdevue.com> && Ivan Brezhnev <brezhnev.ivan@yahoo.com>

MODXTalsk flexible extension of voting for MODX Revolution. This component allows you to install a fully AJAX commenting system on any webpage.

See the documentation here: http://modxtalks.artdevue.com/en/help.html
The source code: http://github.com/artdevue/modxtalks
Issues: http://github.com/artdevue/modxtalks/issues
',
    'changelog' => 'Changelog file for modxTalks component.

modxTalks 1.0.4 pl
======================================
- New. Setting to turn off scrubber

modxTalks 1.0.2 beta
======================================
- New. Full remove comment from database with recalculate other comments indexes
- Fixed. Approve comment if conversation has no comments
- Fixed. Comment link if resource has no ".html" suffix
- Other small fixes

modxTalks 1.0.0
======================================
- [FS#6] New. Displaying Comments reverse, new top, if select NO, the new comments are below.

modxTalks 0.0.2
======================================
- [FS#3]  Fixed. Customize style is the message as hard to see.
- [FS#4]  Fixed. javascript - loading of the last comment at 21, 41, etc. comments.
- [FS#9]  Improved. Compress all image files.
- [FS#10] Fixed. properties.inc.php include snippets for modxTalks.
- [FS#11] Fixed. The panel of resource management, by changing the type of resource, and not hang menyaetsya a resource with comments.
- [FS#12] Fixed. When quoting comment name without quotes added
- [FS#14] Fixed. Compatibility with jQuery 1,9.
- [FS#15] Fixed. Front, does not translate into a splitter time, ie it remains as such when booting.
- [FS#19] Fixed. Plugin to OnSiteRefresh ejs does not remove files.
- [FS#37] Fixed. RSS news.
- [FS#39] New. Add to admin panel grid locks Email addresses
- [FS#1]  Fixed. Permissions for moderators
- [FS#5]  Fixed. The problem with pagination.
- [FS#7]  New. Front-Part. Create button - "comment" in order to be able to comment on the text of the resource.
- [FS#8]  New. When you click on the link in the comments, displaying INPUT which will link to copy.
- [FS#13] New. Vote for comments
- [FS#21] New. The conclusion of the latest comments to modxTalks
- [FS#22] New. Create a placeholder for the output display the number of comments in the topic
- [FS#23] New. Plugin for output to tape number Comment
- [FS#24] Fixed. Problems with styles, rewritten styles modxTalks prefixed
- [FS#25] New. Print a chunk layer for CRC
- [FS#41] New. Added Ukrainian translation
- [FS#42] New. Blocking by IP and Email address from the front
',
    'setup-options' => 'modxtalks-1.0.4-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1cc6f2e5b48b178b6af63c7567d80f53',
      'native_key' => 'modxtalks',
      'filename' => 'modNamespace/33ec092d083e0f7b29a977ad0fe9ad77.vehicle',
      'namespace' => 'modxtalks',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f5f05897521b25475baaefb223760640',
      'native_key' => 'modxtalks',
      'filename' => 'modMenu/b602cb02a29eec20da45810a0850eff5.vehicle',
      'namespace' => 'modxtalks',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '19cf55124d1d348ec16173e8edd9ab0c',
      'native_key' => 'modxtalks.comments_unconfirmed',
      'filename' => 'modMenu/ad61cd49925a2b655331fe89b47f352d.vehicle',
      'namespace' => 'modxtalks',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'eb0ec3348cf43e220655ce3e1115cf3e',
      'native_key' => 'modxtalks.conversations',
      'filename' => 'modMenu/0d8590dafe4529a567d904d4c03512d6.vehicle',
      'namespace' => 'modxtalks',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9ddef534029bd078cf5bf32ee64ab862',
      'native_key' => 'modxtalks.blocking_ip',
      'filename' => 'modMenu/d51fc7fe84a13c01b6a53beb7edf1391.vehicle',
      'namespace' => 'modxtalks',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8d4f166ac72a648e89b3b7b192b0c6fc',
      'native_key' => 'modxtalks.blocking_email',
      'filename' => 'modMenu/568bbc535a85a13b62a0e4fa5c801be7.vehicle',
      'namespace' => 'modxtalks',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5a59a35b57dd6c76e60aaa568f91357b',
      'native_key' => 'modxtalks.help',
      'filename' => 'modMenu/9df2b5233e13f82f3b0b1ec1af56102c.vehicle',
      'namespace' => 'modxtalks',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '41a81907e63dcff87f4838b8b4893d5a',
      'native_key' => 'modxtalks.demo',
      'filename' => 'modMenu/852ccbb7fbdfc75b97a347c5cb0cff5c.vehicle',
      'namespace' => 'modxtalks',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '042c1b054bb7946c1696060c8ac34c6a',
      'native_key' => 'modxtalks.emailsFrom',
      'filename' => 'modSystemSetting/c020aaf26c699601620e59cca31085ac.vehicle',
      'namespace' => 'modxtalks',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be2ee833626a5ded0288303ecf35d3b6',
      'native_key' => 'modxtalks.emailsReplyTo',
      'filename' => 'modSystemSetting/b28491a5aa63f3c303fae1fa34e4d0b9.vehicle',
      'namespace' => 'modxtalks',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfcecc0d678de874e3681c80126c9189',
      'native_key' => 'modxtalks.highlight',
      'filename' => 'modSystemSetting/1dd972a034ca26dd444d4b1619df6d52.vehicle',
      'namespace' => 'modxtalks',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bb4233022afb08dfed44ec67c1b516f',
      'native_key' => 'modxtalks.highlighttheme',
      'filename' => 'modSystemSetting/868445e06846b7519f188899156ec02b.vehicle',
      'namespace' => 'modxtalks',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fef78c6fe9ef4717d4575fae4c7d32a0',
      'native_key' => 'modxtalks.smileys',
      'filename' => 'modSystemSetting/f8d630783c2b81294b3cb2510dd9e168.vehicle',
      'namespace' => 'modxtalks',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6d2b118e1bb6724e026c84078ff9a2a',
      'native_key' => 'modxtalks.editOptionsControls',
      'filename' => 'modSystemSetting/4288687658c0c101e45416ae07e47767.vehicle',
      'namespace' => 'modxtalks',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8c4029d7c1da9b4282ca8418e221fde',
      'native_key' => 'modxtalks.detectUrls',
      'filename' => 'modSystemSetting/d73441ab8a5cb01d70c2672d4b7a1a52.vehicle',
      'namespace' => 'modxtalks',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1888536ea43b1879edbefeb34f5deb00',
      'native_key' => 'modxtalks.bbcode',
      'filename' => 'modSystemSetting/3a237e0e9affa027960e37da281ff61d.vehicle',
      'namespace' => 'modxtalks',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbf41d9633a8a43ce313cbed30aabb0c',
      'native_key' => 'modxtalks.voting',
      'filename' => 'modSystemSetting/9f870d17c59138dae025f20e03e710c9.vehicle',
      'namespace' => 'modxtalks',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae6710ff9fde309fef9969dd9214830c',
      'native_key' => 'modxtalks.revers',
      'filename' => 'modSystemSetting/e1a9123637e04b62e803bdf5331ab34d.vehicle',
      'namespace' => 'modxtalks',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95692acb88500b7ed531fbfd72ab39d7',
      'native_key' => 'modxtalks.scrubber',
      'filename' => 'modSystemSetting/62c118c83903a63dd8af0e8a4dd150e1.vehicle',
      'namespace' => 'modxtalks',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '675bc9c1a19f54a78676d25ae3fc445b',
      'native_key' => 'modxtalks.scrubberTop',
      'filename' => 'modSystemSetting/f5e0f9b4b89b309633c2af7185b4455e.vehicle',
      'namespace' => 'modxtalks',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '346d0fea93a6403ea9c67e80f7585118',
      'native_key' => 'modxtalks.scrubberOffsetTop',
      'filename' => 'modSystemSetting/cef032890a5464a2d24e5349aef43c80.vehicle',
      'namespace' => 'modxtalks',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e198c63f33f2d5aa15507ef7050bcda3',
      'native_key' => 'modxtalks.preModarateComments',
      'filename' => 'modSystemSetting/fd36f49a3bda84354affe46ac29cf8aa.vehicle',
      'namespace' => 'modxtalks',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b877f43d5a7b5ff4bc1e779bd161162a',
      'native_key' => 'modxtalks.onlyAuthUsers',
      'filename' => 'modSystemSetting/496af360df61a5699e7c630c15bec16f.vehicle',
      'namespace' => 'modxtalks',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21be8800ef573771e52c80b021d496bb',
      'native_key' => 'modxtalks.moderator',
      'filename' => 'modSystemSetting/68f1f7cd62068b2baa73ed84e7dfb78e.vehicle',
      'namespace' => 'modxtalks',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15fbf83ff6c36507ce071a184b46c034',
      'native_key' => 'modxtalks.gravatarSize',
      'filename' => 'modSystemSetting/6fc97407303de7bfeacf094c32fac054.vehicle',
      'namespace' => 'modxtalks',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '469c7c74854f53359e6e9ffc84791d53',
      'native_key' => 'modxtalks.gravatar',
      'filename' => 'modSystemSetting/0a1aff9816e78ba6e0fa648647ce056b.vehicle',
      'namespace' => 'modxtalks',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b929ca38b82849afadc820b92717e4b0',
      'native_key' => 'modxtalks.edit_time',
      'filename' => 'modSystemSetting/38a28a9490ac9cda0127d67790177b7d.vehicle',
      'namespace' => 'modxtalks',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd442809db1ffaa3a693c7be4f6f3a072',
      'native_key' => 'modxtalks.defaultAvatar',
      'filename' => 'modSystemSetting/8c9d1883bda8c9f46380033ab3f7ad7e.vehicle',
      'namespace' => 'modxtalks',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e784c662a0c99d107342173819e98252',
      'native_key' => 'modxtalks.dateFormat',
      'filename' => 'modSystemSetting/3277572a300c8155ef3bd0ddf8f33ff2.vehicle',
      'namespace' => 'modxtalks',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2012f9b639b28ff8967012f7f81ec072',
      'native_key' => 'modxtalks.commentsPerPage',
      'filename' => 'modSystemSetting/b1636ca2741a892f7a07533769ba1693.vehicle',
      'namespace' => 'modxtalks',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e368b24c5a4483b4bc88c0eac2f48050',
      'native_key' => 'modxtalks.commentLength',
      'filename' => 'modSystemSetting/b459e5f1f5b9396f2e7dc0aa63aec1e3.vehicle',
      'namespace' => 'modxtalks',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dc25c15311b95bc293e38e943c51909',
      'native_key' => 'modxtalks.ajax',
      'filename' => 'modSystemSetting/264b0f7b8d63a9facb42f596a4a2cd18.vehicle',
      'namespace' => 'modxtalks',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b9ee4ace94f3e927f7f4471db2d8326',
      'native_key' => 'modxtalks.add_timeout',
      'filename' => 'modSystemSetting/3283aa6567e29b9bdd6f64bef9fd27b7.vehicle',
      'namespace' => 'modxtalks',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '573eb39a8288d5d6539ac624af98ceda',
      'native_key' => 'modxtalks.fullDeleteComment',
      'filename' => 'modSystemSetting/7cab2be00cb589fc37310c7d1d0876f1.vehicle',
      'namespace' => 'modxtalks',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '9cb56cda6ef31b6caca21eccbac07f35',
      'native_key' => 1,
      'filename' => 'modPlugin/81eabd6af8b7ab6db32e45fe2da0efce.vehicle',
      'namespace' => 'modxtalks',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00e810b79dc535d816465476f80e7b9b',
      'native_key' => 'OnModxTalksCommentAfterAdd',
      'filename' => 'modEvent/670ffec5b6cab9eec63def244ca595b8.vehicle',
      'namespace' => 'modxtalks',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dde3770523a2d7873f41d84d80e1768b',
      'native_key' => 'OnModxTalksCommentBeforeAdd',
      'filename' => 'modEvent/bf335a30cf95ce9cba887f55daa055bf.vehicle',
      'namespace' => 'modxtalks',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09b1b928b03734cf9399d57d85b343f3',
      'native_key' => 'OnModxTalksCommentAfterRemove',
      'filename' => 'modEvent/38426c35ac0203e38ebb56d1984cda67.vehicle',
      'namespace' => 'modxtalks',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f77725e2f46d0d677852d7a803905149',
      'native_key' => 'OnModxTalksCommentBeforeRemove',
      'filename' => 'modEvent/699a899a899bf3a81ea074b8eef6c34c.vehicle',
      'namespace' => 'modxtalks',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e606c597d4cd305e18ac43a771eb0a50',
      'native_key' => 1,
      'filename' => 'modCategory/829c44b7a2929e935fb0474431904880.vehicle',
      'namespace' => 'modxtalks',
    ),
  ),
);